#include <chrono>
#include <future>
#include <iostream>
#include <random>

// Oblicz pi w 100 iteracjach algorytmu monte carlo następnie porównaj
// dokładność wersji jednowątkowej z wielowątkową, wykorzystaj std::packaged_task
// std::cout.precision(n) pomoże w wyświetlaniu cyfr z dużą dokładnośćią

void exercise1(){
  //Miejsce na rozwiązanie
}

int main(int argc, char **argv) {
  exercise1();
  return 0;
}
